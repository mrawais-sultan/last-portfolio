'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import Hero from './components/Hero'
import About from './components/About'
import Skills from './components/Skills'
import Projects from './components/Projects'
import Blog from './components/Blog'
import Contact from './components/Contact'
import Footer from './components/Footer'
import ArrowNavigation from './components/ArrowNavigation'
import NavigationOverlay from './components/NavigationOverlay'
import { FeatureProvider } from './context/FeatureContext'
import HomeButton from './components/HomeButton'

export default function Home() {
  const [darkMode, setDarkMode] = useState(false)

  useEffect(() => {
    const isDarkMode = localStorage.getItem('darkMode') === 'true'
    setDarkMode(isDarkMode)
    document.documentElement.style.scrollBehavior = 'smooth'
    return () => {
      document.documentElement.style.scrollBehavior = 'auto'
    }
  }, [])

  const toggleDarkMode = () => {
    const newDarkMode = !darkMode
    setDarkMode(newDarkMode)
    localStorage.setItem('darkMode', newDarkMode.toString())
  }

  return (
    <FeatureProvider>
      <main className={`min-h-screen ${darkMode ? 'dark' : ''}`}>
        <div className="fixed top-4 right-4 z-50">
          <button
            onClick={toggleDarkMode}
            className="rounded-full bg-gray-200 p-2 text-gray-800 transition-colors duration-200 hover:bg-gray-300 dark:bg-gray-800 dark:text-gray-200 dark:hover:bg-gray-700"
          >
            {darkMode ? '🌞' : '🌙'}
          </button>
        </div>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="relative"
        >
          <Hero />
          <About />
          <Skills />
          <Projects />
          <Blog />
          <Contact />
          <Footer />
          <ArrowNavigation />
          <NavigationOverlay />
          <HomeButton />
        </motion.div>
      </main>
    </FeatureProvider>
  )
}

