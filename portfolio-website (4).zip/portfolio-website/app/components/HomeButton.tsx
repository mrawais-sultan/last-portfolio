'use client'

import { motion } from 'framer-motion'
import { Home } from 'lucide-react'

export default function HomeButton() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  return (
    <motion.button
      onClick={scrollToTop}
      className="fixed left-8 top-8 z-40 rounded-full bg-white/10 p-3 backdrop-blur-sm transition-all hover:bg-white/20 dark:bg-gray-800/10 dark:hover:bg-gray-800/20"
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.9 }}
      aria-label="Scroll to top"
    >
      <Home className="h-6 w-6 text-gray-800 dark:text-white" />
      <span className="sr-only">Scroll to top</span>
    </motion.button>
  )
}

