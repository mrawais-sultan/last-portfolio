'use client'

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { X } from 'lucide-react'

interface Bubble {
  id: number
  x: number
  y: number
  content: string
}

const skills = [
  "React", "Next.js", "TypeScript", "Node.js", "MongoDB", "AWS",
  "Docker", "Git", "REST APIs", "GraphQL", "Tailwind CSS", "Redux"
]

export default function BubbleGame() {
  const [bubbles, setBubbles] = useState<Bubble[]>([])
  const [score, setScore] = useState(0)
  const [isVisible, setIsVisible] = useState(true)

  useEffect(() => {
    const interval = setInterval(() => {
      if (bubbles.length < 5) {
        const newBubble = {
          id: Date.now(),
          x: Math.random() * (window.innerWidth - 100),
          y: window.innerHeight,
          content: skills[Math.floor(Math.random() * skills.length)]
        }
        setBubbles(prev => [...prev, newBubble])
      }
    }, 2000)

    return () => clearInterval(interval)
  }, [bubbles])

  const popBubble = (id: number) => {
    setBubbles(prev => prev.filter(bubble => bubble.id !== id))
    setScore(prev => prev + 1)
  }

  if (!isVisible) return null

  return (
    <div className="fixed bottom-4 right-4 z-40">
      <div className="relative rounded-lg bg-white/10 p-4 backdrop-blur-sm">
        <button
          onClick={() => setIsVisible(false)}
          className="absolute -right-2 -top-2 rounded-full bg-red-500 p-1 text-white hover:bg-red-600"
        >
          <X className="h-4 w-4" />
        </button>
        <div className="mb-2 text-white">Score: {score}</div>
        <AnimatePresence>
          {bubbles.map(bubble => (
            <motion.button
              key={bubble.id}
              initial={{ y: 0, opacity: 0 }}
              animate={{ y: -200, opacity: 1 }}
              exit={{ opacity: 0, scale: 0 }}
              transition={{ duration: 3 }}
              onClick={() => popBubble(bubble.id)}
              className="absolute rounded-full bg-gradient-to-r from-blue-400 to-indigo-500 px-3 py-1 text-sm text-white hover:scale-110"
              style={{ left: bubble.x, top: bubble.y }}
            >
              {bubble.content}
            </motion.button>
          ))}
        </AnimatePresence>
      </div>
    </div>
  )
}

