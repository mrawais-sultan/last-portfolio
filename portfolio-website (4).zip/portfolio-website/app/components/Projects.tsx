'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import Image from 'next/image'
import { X, ExternalLink, Github, ChevronLeft, ChevronRight } from 'lucide-react'

interface Project {
  id: number
  name: string
  description: string
  longDescription: string
  image: string
  techStack: string[]
  category: string
  liveLink: string
  githubLink: string
  featured: boolean
}

const projects: Project[] = [
  {
    id: 1,
    name: 'E-Commerce Platform',
    description: 'A modern e-commerce platform built with Next.js and Stripe',
    longDescription: 'A full-featured e-commerce platform with product management, cart functionality, and secure payments through Stripe integration. Built with Next.js, TypeScript, and Tailwind CSS.',
    image: '/placeholder.svg',
    techStack: ['React', 'Next.js', 'TypeScript', 'Stripe'],
    category: 'Full Stack',
    liveLink: 'https://project1.com',
    githubLink: 'https://github.com/johndoe/project1',
    featured: true
  },
  {
    id: 2,
    name: 'AI Chat Application',
    description: 'Real-time chat app with AI-powered responses',
    longDescription: 'An innovative chat application that leverages OpenAI\'s GPT-4 for intelligent responses. Features real-time messaging, code highlighting, and file sharing.',
    image: '/placeholder.svg',
    techStack: ['React', 'Socket.io', 'OpenAI API', 'Node.js'],
    category: 'Full Stack',
    liveLink: 'https://project2.com',
    githubLink: 'https://github.com/johndoe/project2',
    featured: false
  },
  {
    id: 3,
    name: 'Portfolio Generator',
    description: 'Dynamic portfolio website generator with customizable themes',
    longDescription: 'A tool that helps developers create stunning portfolio websites with minimal effort. Includes theme customization, project showcases, and blog integration.',
    image: '/placeholder.svg',
    techStack: ['Vue.js', 'Nuxt.js', 'TailwindCSS'],
    category: 'Frontend',
    liveLink: 'https://project3.com',
    githubLink: 'https://github.com/johndoe/project3',
    featured: false
  }
]

const categories = ['All', 'Full Stack', 'Frontend', 'Backend', 'Mobile']

export default function Projects() {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null)
  const [selectedCategory, setSelectedCategory] = useState('All')
  const [currentImageIndex, setCurrentImageIndex] = useState(0)

  const filteredProjects = projects.filter(
    project => selectedCategory === 'All' || project.category === selectedCategory
  )

  const featuredProject = projects.find(p => p.featured)

  return (
    <section id="projects" className="bg-gray-100 py-20 dark:bg-gray-900">
      <div className="container mx-auto px-4">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-10 text-center text-3xl font-bold text-gray-800 dark:text-gray-200 md:text-4xl"
        >
          My Projects
        </motion.h2>

        {/* Featured Project */}
        {featuredProject && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-16"
          >
            <h3 className="mb-6 text-center text-xl font-semibold text-gray-600 dark:text-gray-400">
              Featured Project
            </h3>
            <div className="overflow-hidden rounded-xl bg-white shadow-xl dark:bg-gray-800">
              <div className="relative aspect-video">
                <Image
                  src={featuredProject.image}
                  alt={featuredProject.name}
                  layout="fill"
                  objectFit="cover"
                  className="transition-transform duration-300 hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                <div className="absolute bottom-0 left-0 p-6 text-white">
                  <h4 className="mb-2 text-2xl font-bold">{featuredProject.name}</h4>
                  <p className="text-gray-200">{featuredProject.description}</p>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Category Filter */}
        <div className="mb-12 flex flex-wrap justify-center gap-4">
          {categories.map((category) => (
            <motion.button
              key={category}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setSelectedCategory(category)}
              className={`rounded-full px-6 py-2 text-sm font-medium transition-all duration-300 ${
                selectedCategory === category
                  ? 'bg-gradient-to-r from-blue-500 to-indigo-500 text-white shadow-lg'
                  : 'bg-white text-gray-600 hover:bg-gray-50 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-gray-700'
              }`}
            >
              {category}
            </motion.button>
          ))}
        </div>

        {/* Projects Grid */}
        <motion.div layout className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          <AnimatePresence mode="popLayout">
            {filteredProjects.map((project) => (
              <motion.div
                key={project.id}
                layout
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                whileHover={{ y: -10 }}
                className="group relative overflow-hidden rounded-xl bg-white shadow-lg transition-all duration-300 hover:shadow-xl dark:bg-gray-800"
                onClick={() => setSelectedProject(project)}
              >
                <div className="relative aspect-video">
                  <Image
                    src={project.image}
                    alt={project.name}
                    layout="fill"
                    objectFit="cover"
                    className="w-full h-40 object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
                </div>
                <div className="p-4">
                  <h3 className="mb-2 text-xl font-semibold text-gray-800 dark:text-gray-200">
                    {project.name}
                  </h3>
                  <p className="mb-4 text-gray-600 dark:text-gray-400">{project.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {project.techStack.map((tech) => (
                      <span
                        key={tech}
                        className="rounded-full bg-gray-100 px-3 py-1 text-sm text-gray-600 dark:bg-gray-700 dark:text-gray-300"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

        {/* Project Modal */}
        <AnimatePresence>
          {selectedProject && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
              onClick={() => setSelectedProject(null)}
            >
              <motion.div
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                onClick={(e) => e.stopPropagation()}
                className="relative max-h-[90vh] w-full max-w-4xl overflow-auto rounded-2xl bg-white p-6 shadow-2xl dark:bg-gray-800"
              >
                {/* Close Button */}
                <button
                  onClick={() => setSelectedProject(null)}
                  className="absolute right-4 top-4 rounded-full bg-gray-100 p-2 text-gray-600 transition-colors hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-300 dark:hover:bg-gray-600"
                >
                  <X className="h-5 w-5" />
                </button>

                {/* Project Content */}
                <div className="space-y-6">
                  {/* Image Carousel */}
                  <div className="relative aspect-video overflow-hidden rounded-lg">
                    <Image
                      src={selectedProject.image}
                      alt={selectedProject.name}
                      layout="fill"
                      objectFit="cover"
                    />
                    {/* Navigation Arrows */}
                    <button
                      onClick={() => setCurrentImageIndex((prev) => Math.max(0, prev - 1))}
                      className="absolute left-4 top-1/2 -translate-y-1/2 rounded-full bg-black/30 p-2 text-white backdrop-blur-sm transition-all hover:bg-black/50"
                    >
                      <ChevronLeft className="h-6 w-6" />
                    </button>
                    <button
                      onClick={() => setCurrentImageIndex((prev) => prev + 1)}
                      className="absolute right-4 top-1/2 -translate-y-1/2 rounded-full bg-black/30 p-2 text-white backdrop-blur-sm transition-all hover:bg-black/50"
                    >
                      <ChevronRight className="h-6 w-6" />
                    </button>
                  </div>

                  {/* Project Info */}
                  <div>
                    <h3 className="text-2xl font-bold text-gray-800 dark:text-gray-200">
                      {selectedProject.name}
                    </h3>
                    <p className="mt-4 text-gray-600 dark:text-gray-400">
                      {selectedProject.longDescription}
                    </p>
                  </div>

                  {/* Tech Stack */}
                  <div>
                    <h4 className="mb-2 text-lg font-semibold text-gray-800 dark:text-gray-200">
                      Technologies Used
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {selectedProject.techStack.map((tech) => (
                        <span
                          key={tech}
                          className="rounded-full bg-gradient-to-r from-blue-500 to-indigo-500 px-4 py-1 text-sm text-white"
                        >
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Project Links */}
                  <div className="flex gap-4">
                    <a
                      href={selectedProject.liveLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="group flex items-center gap-2 rounded-lg bg-gradient-to-r from-blue-500 to-indigo-500 px-6 py-2 text-white transition-all hover:shadow-lg"
                    >
                      <ExternalLink className="h-5 w-5 transition-transform group-hover:-translate-y-1 group-hover:translate-x-1" />
                      Live Demo
                    </a>
                    <a
                      href={selectedProject.githubLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="group flex items-center gap-2 rounded-lg border-2 border-gray-200 px-6 py-2 text-gray-600 transition-all hover:border-gray-300 hover:shadow-lg dark:border-gray-700 dark:text-gray-300 dark:hover:border-gray-600"
                    >
                      <Github className="h-5 w-5 transition-transform group-hover:scale-110" />
                      View Code
                    </a>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  )
}

