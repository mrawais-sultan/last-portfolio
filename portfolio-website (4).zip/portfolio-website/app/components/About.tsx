'use client'

import { motion } from 'framer-motion'
import Image from 'next/image'
import { Download } from 'lucide-react'

export default function About() {
  const handleDownloadResume = () => {
    // Replace with actual resume file path
    const resumeUrl = '/resume.pdf'
    window.open(resumeUrl, '_blank')
  }

  return (
    <section id="about" className="py-20 bg-gray-100 dark:bg-gray-900">
      <div className="container mx-auto px-4">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="text-3xl md:text-4xl font-bold text-center mb-10 text-gray-800 dark:text-gray-200"
        >
          About Me
        </motion.h2>
        <div className="flex flex-col md:flex-row items-center justify-between gap-12">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            viewport={{ once: true }}
            className="md:w-1/2 relative"
          >
            <div className="relative w-64 h-64 mx-auto">
              <motion.div
                animate={{
                  scale: [1, 1.02, 1],
                  rotate: [0, 1, -1, 0],
                }}
                transition={{
                  duration: 4,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
                className="absolute inset-0 rounded-full bg-gradient-to-r from-blue-400 to-indigo-600 opacity-75 blur-lg"
              />
              <Image
                src="/placeholder.svg"
                alt="Awais Khan"
                width={256}
                height={256}
                className="relative rounded-full shadow-xl"
              />
            </div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            viewport={{ once: true }}
            className="md:w-1/2"
          >
            <div className="space-y-6">
              <p className="text-lg text-gray-700 dark:text-gray-300">
                Hi, I'm Awais Khan, a passionate software engineer with over 5 years of experience in developing innovative web applications. My journey in tech started with a curiosity for problem-solving and has evolved into a career focused on creating efficient, scalable, and user-friendly solutions.
              </p>
              <p className="text-lg text-gray-700 dark:text-gray-300">
                I specialize in full-stack development, with expertise in React, Node.js, and cloud technologies. My goal is to leverage technology to build products that make a positive impact on people's lives.
              </p>
              <motion.button
                onClick={handleDownloadResume}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="group relative overflow-hidden rounded-lg bg-gradient-to-r from-blue-500 to-indigo-600 px-6 py-3 text-white shadow-lg transition-all duration-300 hover:shadow-xl"
              >
                <motion.div
                  className="absolute inset-0 bg-white"
                  initial={{ x: "100%" }}
                  whileHover={{ x: "0%" }}
                  transition={{ duration: 0.3 }}
                  style={{ opacity: 0.2 }}
                />
                <span className="relative flex items-center gap-2">
                  <Download className="h-5 w-5" />
                  Download Resume
                </span>
              </motion.button>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

