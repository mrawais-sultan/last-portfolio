'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Code2, Server, Database, Wrench, Search } from 'lucide-react'

interface Skill {
  name: string
  icon: any
  category: string
  proficiency: number
  description: string
}

const skills: Skill[] = [
  {
    name: 'React',
    icon: Code2,
    category: 'Frontend',
    proficiency: 90,
    description: 'Building modern web applications with React and Next.js'
  },
  {
    name: 'Node.js',
    icon: Server,
    category: 'Backend',
    proficiency: 85,
    description: 'Server-side development with Express and TypeScript'
  },
  {
    name: 'MongoDB',
    icon: Database,
    category: 'Database',
    proficiency: 80,
    description: 'NoSQL database design and optimization'
  },
  {
    name: 'DevOps',
    icon: Wrench,
    category: 'Tools',
    proficiency: 75,
    description: 'CI/CD, Docker, and cloud deployment'
  },
  {
    name: 'GraphQL',
    icon: Code2,
    category: 'Backend',
    proficiency: 85,
    description: 'Building efficient, type-safe APIs with GraphQL'
  },
  {
    name: 'TypeScript',
    icon: Code2,
    category: 'Frontend',
    proficiency: 90,
    description: 'Writing type-safe JavaScript applications'
  },
  {
    name: 'AWS',
    icon: Server,
    category: 'Tools',
    proficiency: 80,
    description: 'Cloud infrastructure and serverless computing'
  },
  {
    name: 'Vue.js',
    icon: Code2,
    category: 'Frontend',
    proficiency: 75,
    description: 'Building reactive web applications with Vue.js'
  }
]

const categories = ['All', 'Frontend', 'Backend', 'Database', 'Tools']

export default function Skills() {
  const [selectedCategory, setSelectedCategory] = useState('All')
  const [hoveredSkill, setHoveredSkill] = useState<string | null>(null)

  const filteredSkills = skills.filter(
    skill => selectedCategory === 'All' || skill.category === selectedCategory
  )

  return (
    <section id="skills" className="relative overflow-hidden bg-white py-20 dark:bg-gray-800">
      {/* Animated Background */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-400 to-indigo-600" />
        {Array.from({ length: 50 }).map((_, i) => (
          <motion.div
            key={i}
            className="absolute h-2 w-2 rounded-full bg-current"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -30, 0],
              opacity: [0.2, 0.5, 0.2],
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              ease: "easeInOut",
              delay: Math.random() * 2,
            }}
          />
        ))}
      </div>

      <div className="container relative mx-auto px-4">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-10 text-center text-3xl font-bold text-gray-800 dark:text-gray-200 md:text-4xl"
        >
          My Skills
        </motion.h2>

        {/* Category Filter */}
        <div className="mb-12 flex flex-wrap justify-center gap-4">
          {categories.map((category) => (
            <motion.button
              key={category}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setSelectedCategory(category)}
              className={`rounded-full px-6 py-2 text-sm font-medium transition-all duration-300 ${
                selectedCategory === category
                  ? 'bg-gradient-to-r from-blue-500 to-indigo-500 text-white shadow-lg'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-300 dark:hover:bg-gray-600'
              }`}
            >
              {category}
            </motion.button>
          ))}
        </div>

        {/* Skills Grid */}
        <motion.div
          layout
          className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4"
        >
          <AnimatePresence mode="popLayout">
            {filteredSkills.map((skill) => (
              <motion.div
                key={skill.name}
                layout
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                whileHover={{ scale: 1.05 }}
                onHoverStart={() => setHoveredSkill(skill.name)}
                onHoverEnd={() => setHoveredSkill(null)}
                className="group relative rounded-xl bg-white p-6 shadow-lg transition-all duration-300 hover:shadow-xl dark:bg-gray-700"
              >
                {/* Skill Icon */}
                <div className="mb-4 flex justify-center">
                  <div className="relative">
                    <div className="absolute inset-0 animate-ping rounded-full bg-blue-400 opacity-20" />
                    <div className="relative rounded-full bg-gradient-to-r from-blue-500 to-indigo-500 p-4">
                      <skill.icon className="h-8 w-8 text-white" />
                    </div>
                  </div>
                </div>

                {/* Skill Info */}
                <h3 className="mb-2 text-center text-lg font-semibold text-gray-800 dark:text-gray-200">
                  {skill.name}
                </h3>
                <p className="mb-4 text-center text-sm text-gray-600 dark:text-gray-400">
                  {skill.category}
                </p>

                {/* Progress Bar */}
                <div className="h-2 overflow-hidden rounded-full bg-gray-200 dark:bg-gray-600">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${skill.proficiency}%` }}
                    transition={{ duration: 1, ease: "easeOut" }}
                    className="h-full bg-gradient-to-r from-blue-500 to-indigo-500"
                  />
                </div>

                {/* Hover Description */}
                <AnimatePresence>
                  {hoveredSkill === skill.name && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 10 }}
                      className="absolute inset-0 flex items-center justify-center rounded-xl bg-gradient-to-r from-blue-500/90 to-indigo-500/90 p-4 text-white backdrop-blur-sm"
                    >
                      <p className="text-center text-sm">{skill.description}</p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
      </div>
    </section>
  )
}

