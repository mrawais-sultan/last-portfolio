'use client'

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { ChevronDown, ChevronUp } from 'lucide-react'

const sections = ['hero', 'about', 'skills', 'projects', 'blog', 'contact']

export default function ArrowNavigation() {
  const [currentSection, setCurrentSection] = useState(0)

  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY
      const windowHeight = window.innerHeight
      
      // Find the current section based on scroll position
      let newSection = 0
      sections.forEach((_, index) => {
        const element = document.getElementById(sections[index])
        if (element) {
          const rect = element.getBoundingClientRect()
          if (rect.top <= windowHeight / 2) {
            newSection = index
          }
        }
      })
      setCurrentSection(newSection)
    }

    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const scrollToSection = (direction: 'up' | 'down') => {
    const nextSection = direction === 'down' ? currentSection + 1 : currentSection - 1
    if (nextSection >= 0 && nextSection < sections.length) {
      const element = document.getElementById(sections[nextSection])
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' })
      }
    }
  }

  return (
    <AnimatePresence>
      <div className="fixed right-8 z-40 flex flex-col items-end gap-4">
        {/* Navigation Arrows */}
        {currentSection > 0 && (
          <motion.button
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            onClick={() => scrollToSection('up')}
            className="group fixed left-1/2 top-8 -translate-x-1/2 transform"
          >
            <div className="flex flex-col items-center gap-2">
              <ChevronUp className="h-8 w-8 text-gray-800/70 transition-all duration-300 group-hover:scale-110 group-hover:text-violet-500 dark:text-white/70" />
              <span className="text-sm font-medium text-gray-800/70 opacity-0 transition-opacity duration-300 group-hover:opacity-100 dark:text-white/70">
                Previous
              </span>
            </div>
          </motion.button>
        )}

        {currentSection < sections.length - 1 && (
          <motion.button
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            onClick={() => scrollToSection('down')}
            className="group fixed bottom-8 left-1/2 -translate-x-1/2 transform"
          >
            <div className="flex flex-col items-center gap-2">
              <span className="text-sm font-medium text-gray-800/70 opacity-0 transition-opacity duration-300 group-hover:opacity-100 dark:text-white/70">
                Next
              </span>
              <ChevronDown className="h-8 w-8 text-gray-800/70 transition-all duration-300 group-hover:scale-110 group-hover:text-violet-500 dark:text-white/70" />
            </div>
          </motion.button>
        )}
      </div>
    </AnimatePresence>
  )
}

