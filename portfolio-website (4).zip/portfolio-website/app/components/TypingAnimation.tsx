'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'

const titles = [
  "Developer",
  "Entrepreneur",
  "Problem Solver",
  "Turning Ideas into Code"
]

export default function TypingAnimation() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isDeleting, setIsDeleting] = useState(false)
  const [text, setText] = useState('')

  useEffect(() => {
    const timer = setTimeout(() => {
      const currentText = titles[currentIndex]
      
      if (!isDeleting) {
        if (text.length < currentText.length) {
          setText(currentText.slice(0, text.length + 1))
        } else {
          setTimeout(() => setIsDeleting(true), 1500)
        }
      } else {
        if (text.length > 0) {
          setText(currentText.slice(0, text.length - 1))
        } else {
          setIsDeleting(false)
          setCurrentIndex((prev) => (prev + 1) % titles.length)
        }
      }
    }, isDeleting ? 50 : 100)

    return () => clearTimeout(timer)
  }, [text, isDeleting, currentIndex])

  return (
    <motion.div
      className="h-12 text-3xl font-bold md:text-4xl"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <span className="bg-gradient-to-r from-violet-500 via-fuchsia-500 to-pink-500 bg-clip-text text-transparent animate-gradient-x font-extrabold">
        {text}
      </span>
      <motion.span
        animate={{ opacity: [1, 0] }}
        transition={{ duration: 0.5, repeat: Infinity, repeatType: "reverse" }}
        className="ml-1 inline-block h-8 w-[2px] bg-gradient-to-b from-violet-500 via-fuchsia-500 to-pink-500"
      >
        |
      </motion.span>
    </motion.div>
  )
}

