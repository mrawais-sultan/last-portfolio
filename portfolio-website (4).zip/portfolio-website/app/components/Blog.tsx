'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import Image from 'next/image'
import { Search, Calendar, Clock, Tag, X } from 'lucide-react'

interface BlogPost {
  id: number
  title: string
  snippet: string
  content: string
  image: string
  date: string
  readTime: string
  tags: string[]
}

const blogPosts: BlogPost[] = [
  {
    id: 1,
    title: 'Getting Started with React Hooks',
    snippet: 'Learn how to use React Hooks to simplify your components and manage state more efficiently.',
    content: 'Full content of the blog post goes here...',
    image: '/placeholder.svg',
    date: '2024-01-15',
    readTime: '5 min read',
    tags: ['React', 'JavaScript', 'Web Development']
  },
  {
    id: 2,
    title: 'Building Scalable APIs with GraphQL',
    snippet: 'Explore the benefits of GraphQL and learn how to build efficient, type-safe APIs.',
    content: 'Full content of the blog post goes here...',
    image: '/placeholder.svg',
    date: '2024-01-20',
    readTime: '8 min read',
    tags: ['GraphQL', 'API', 'Backend']
  },
  {
    id: 3,
    title: 'Mastering TypeScript Generics',
    snippet: 'Deep dive into TypeScript generics and how they can make your code more reusable.',
    content: 'Full content of the blog post goes here...',
    image: '/placeholder.svg',
    date: '2024-01-25',
    readTime: '6 min read',
    tags: ['TypeScript', 'JavaScript', 'Programming']
  }
]

const allTags = Array.from(new Set(blogPosts.flatMap(post => post.tags)))

export default function Blog() {
  const [selectedPost, setSelectedPost] = useState<BlogPost | null>(null)
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedTag, setSelectedTag] = useState<string | null>(null)

  const filteredPosts = blogPosts.filter(post => {
    const matchesSearch = post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         post.snippet.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesTag = !selectedTag || post.tags.includes(selectedTag)
    return matchesSearch && matchesTag
  })

  return (
    <section id="blog" className="bg-white py-20 dark:bg-gray-800">
      <div className="container mx-auto px-4">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-10 text-center text-3xl font-bold text-gray-800 dark:text-gray-200 md:text-4xl"
        >
          Blog
        </motion.h2>

        {/* Search and Filter */}
        <div className="mb-8 space-y-4">
          {/* Search Bar */}
          <div className="relative mx-auto max-w-md">
            <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search posts..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full rounded-full bg-gray-100 py-2 pl-10 pr-4 text-gray-800 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-gray-200 dark:placeholder-gray-400"
            />
          </div>

          {/* Tags */}
          <div className="flex flex-wrap justify-center gap-2">
            {allTags.map((tag) => (
              <motion.button
                key={tag}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setSelectedTag(selectedTag === tag ? null : tag)}
                className={`rounded-full px-4 py-1 text-sm transition-all ${
                  selectedTag === tag
                    ? 'bg-gradient-to-r from-blue-500 to-indigo-500 text-white'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-300 dark:hover:bg-gray-600'
                }`}
              >
                {tag}
              </motion.button>
            ))}
          </div>
        </div>

        {/* Blog Posts Grid */}
        <motion.div layout className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          <AnimatePresence mode="popLayout">
            {filteredPosts.map((post) => (
              <motion.article
                key={post.id}
                layout
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                whileHover={{ y: -10 }}
                className="group cursor-pointer overflow-hidden rounded-xl bg-white shadow-lg transition-all duration-300 hover:shadow-xl dark:bg-gray-700"
                onClick={() => setSelectedPost(post)}
              >
                {/* Image */}
                <div className="relative aspect-video overflow-hidden">
                  <Image
                    src={post.image}
                    alt={post.title}
                    layout="fill"
                    objectFit="cover"
                    className="transition-transform duration-300 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
                </div>

                {/* Content */}
                <div className="p-6">
                  {/* Meta */}
                  <div className="mb-4 flex items-center gap-4 text-sm text-gray-500 dark:text-gray-400">
                    <span className="flex items-center gap-1">
                      <Calendar className="h-4 w-4" />
                      {new Date(post.date).toLocaleDateString()}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      {post.readTime}
                    </span>
                  </div>

                  {/* Title & Snippet */}
                  <h3 className="mb-2 text-xl font-bold text-gray-800 dark:text-gray-200">
                    {post.title}
                  </h3>
                  <p className="mb-4 text-gray-600 dark:text-gray-400">{post.snippet}</p>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-2">
                    {post.tags.map((tag) => (
                      <span
                        key={tag}
                        className="rounded-full bg-gray-100 px-3 py-1 text-xs text-gray-600 dark:bg-gray-600 dark:text-gray-300"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </motion.article>
            ))}
          </AnimatePresence>
        </motion.div>
        {/* Blog Post Modal */}
        <AnimatePresence>
          {selectedPost && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
              onClick={() => setSelectedPost(null)}
            >
              <motion.div
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                onClick={(e) => e.stopPropagation()}
                className="relative max-h-[90vh] w-full max-w-4xl overflow-auto rounded-2xl bg-white p-6 shadow-2xl dark:bg-gray-800"
              >
                {/* Close Button */}
                <button
                  onClick={() => setSelectedPost(null)}
                  className="absolute right-4 top-4 rounded-full bg-gray-100 p-2 text-gray-600 transition-colors hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-300 dark:hover:bg-gray-600"
                >
                  <X className="h-5 w-5" />
                </button>

                {/* Post Content */}
                <div className="space-y-6">
                  <div className="relative aspect-video overflow-hidden rounded-lg">
                    <Image
                      src={selectedPost.image}
                      alt={selectedPost.title}
                      layout="fill"
                      objectFit="cover"
                    />
                  </div>

                  <div>
                    <h3 className="text-2xl font-bold text-gray-800 dark:text-gray-200">
                      {selectedPost.title}
                    </h3>
                    <div className="mt-2 flex items-center gap-4 text-sm text-gray-500 dark:text-gray-400">
                      <span className="flex items-center gap-1">
                        <Calendar className="h-4 w-4" />
                        {new Date(selectedPost.date).toLocaleDateString()}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        {selectedPost.readTime}
                      </span>
                    </div>
                  </div>

                  <div className="prose prose-lg max-w-none dark:prose-invert">
                    {selectedPost.content}
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {selectedPost.tags.map((tag) => (
                      <span
                        key={tag}
                        className="flex items-center gap-1 rounded-full bg-gray-100 px-3 py-1 text-sm text-gray-600 dark:bg-gray-700 dark:text-gray-300"
                      >
                        <Tag className="h-4 w-4" />
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  )
}

