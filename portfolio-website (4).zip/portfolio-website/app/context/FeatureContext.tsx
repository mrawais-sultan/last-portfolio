'use client'

import { createContext, useContext, useState, ReactNode, useEffect } from 'react'
import { motion, useMotionValue, useSpring } from 'framer-motion'

interface FeatureContextType {
  isMouseFollowEnabled: boolean
  toggleMouseFollow: () => void
  cursorXSpring: any
  cursorYSpring: any
}

const FeatureContext = createContext<FeatureContextType | undefined>(undefined)

export function FeatureProvider({ children }: { children: ReactNode }) {
  const [isMouseFollowEnabled, setIsMouseFollowEnabled] = useState(true)
  
  const cursorX = useMotionValue(-100)
  const cursorY = useMotionValue(-100)
  const springConfig = { damping: 20, stiffness: 400, mass: 0.5 }
  const cursorXSpring = useSpring(cursorX, springConfig)
  const cursorYSpring = useSpring(cursorY, springConfig)

  const toggleMouseFollow = () => setIsMouseFollowEnabled(!isMouseFollowEnabled)

  useEffect(() => {
    const moveCursor = (e: MouseEvent) => {
      cursorX.set(e.clientX - 16)
      cursorY.set(e.clientY - 16)
    }
    window.addEventListener('mousemove', moveCursor)
    return () => window.removeEventListener('mousemove', moveCursor)
  }, [])

  return (
    <FeatureContext.Provider
      value={{
        isMouseFollowEnabled,
        toggleMouseFollow,
        cursorXSpring,
        cursorYSpring,
      }}
    >
      {children}
      {isMouseFollowEnabled && (
        <motion.div
          className="pointer-events-none fixed z-50 h-8 w-8 rounded-full bg-gradient-to-r from-violet-500/30 to-fuchsia-500/30 backdrop-blur-sm"
          style={{
            x: cursorXSpring,
            y: cursorYSpring,
            boxShadow: '0 0 20px rgba(139, 92, 246, 0.3)',
            transform: 'translate(-50%, -50%)'
          }}
        />
      )}
    </FeatureContext.Provider>
  )
}

export function useFeatures() {
  const context = useContext(FeatureContext)
  if (context === undefined) {
    throw new Error('useFeatures must be used within a FeatureProvider')
  }
  return context
}

